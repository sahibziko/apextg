### Userbot Qurulum

```console
cd
rm -rf qbot
git clone https://github.com/uumud/qbot &&  cd qbot
pip3 install -U -r requirements.txt
screen -S qbot
python3 main.py
```
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/sjrvan/ApexInstaller"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-red?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a>
